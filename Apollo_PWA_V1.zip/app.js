const chat=document.getElementById('chat'), input=document.getElementById('input'), send=document.getElementById('sendBtn'), mic=document.getElementById('micBtn');
const memoryBtn=document.getElementById('memoryBtn'), panel=document.getElementById('memoryPanel'), closeMemory=document.getElementById('closeMemory'), memoryList=document.getElementById('memoryList'), clearMemory=document.getElementById('clearMemory');
let memories=JSON.parse(localStorage.getItem('apollo_memories')||'[]');

function addBubble(text,who){const d=document.createElement('div');d.className='bubble '+(who==='user'?'user':'apollo');d.innerHTML='<div class="who">'+(who==='user'?'Du':'Apollo')+'</div>'+escapeHtml(text).replace(/\n/g,'<br>');chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function save(){localStorage.setItem('apollo_memories',JSON.stringify(memories))}
function reply(text){
  const t=text.trim(); if(!t)return;
  addBubble(t,'user'); input.value='';
  setTimeout(()=>{
    const low=t.toLowerCase();
    if(low.startsWith('merke dir ')){const m=t.slice(10).trim(); if(m){memories.push(m);save();addBubble('Gespeichert. Ich werde mir das merken.','apollo');}return}
    if(low.includes('was weißt du über mich')||low.includes('was weisst du über mich')){addBubble(memories.length?'Das weiß ich bisher:\n• '+memories.join('\n• '):'Noch nichts. Du hast mir bisher nichts zum Merken gegeben.','apollo');return}
    if(low.includes('vergiss alles')){memories=[];save();addBubble('Mein gespeichertes Gedächtnis ist jetzt leer.','apollo');return}
    addBubble('Ich bin gerade in V1. Mein Gedächtnis funktioniert bereits lokal auf diesem Gerät. Eine echte KI-Antwort kommt in der nächsten Version.','apollo');
  },250)
}
send.onclick=()=>reply(input.value);
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();reply(input.value)}});

memoryBtn.onclick=()=>{renderMemory();panel.classList.remove('hidden')}; closeMemory.onclick=()=>panel.classList.add('hidden');
panel.addEventListener('click',e=>{if(e.target===panel)panel.classList.add('hidden')});
clearMemory.onclick=()=>{memories=[];save();renderMemory()};
function renderMemory(){memoryList.innerHTML=memories.length?memories.map((m,i)=>`<div class="memoryItem">${i+1}. ${escapeHtml(m)}</div>`).join(''):'<p class="muted">Noch keine Erinnerungen.</p>'}

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){const r=new SR();r.lang='de-DE';r.interimResults=false;r.onresult=e=>{input.value=e.results[0][0].transcript};r.onerror=()=>{};mic.onclick=()=>r.start()}else{mic.onclick=()=>addBubble('Spracherkennung wird von diesem Browser nicht unterstützt.','apollo')}

if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
