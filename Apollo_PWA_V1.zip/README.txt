APOLLO V1 – MOBILE PWA

Diese Version startet ohne persönliche Informationen über den Nutzer.
Das lokale Gedächtnis beginnt leer.

TEST:
1. Die Dateien müssen über eine HTTPS-Webadresse bereitgestellt werden, damit Installation und Service Worker funktionieren.
2. Öffne die Adresse in Chrome auf Android.
3. Nutze das Browser-Menü und wähle die angebotene Installationsoption für Apollo.
4. Apollo erscheint anschließend wie eine App auf dem Startbildschirm.

WICHTIG:
V1 ist noch keine echte KI. Sie testet Oberfläche, lokales Gedächtnis, Spracheingabe und PWA-Grundlage.
V2 kann danach eine echte KI-Schnittstelle erhalten. API-Schlüssel sollten dabei nicht direkt in die App geschrieben werden.
